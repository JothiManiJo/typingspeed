# typing-speed-test
A simple tool to test typing skills.